# 24 Aternos

- [Discord](https://discord.gg/bjgpVAxgyE)
- [Youtube](https://youtube.com/c/fortcote)
- [Telegram](https://t.me/FortcoteTG)

| <sub>EN</sub> [English](README.md) | <sub>RU</sub> [русский](README_RU.md) |
|-------------------------|----------------------------|

Данный бот сделан для хостинга aternos игры майнкрафт. Он не позваляет выключится серверу.

### Дисклеймер

> Этот бот создан в образовательных целях и не побуждает вас его использовать. Вы несёте всю ответственность за свой сервер!

 - Бот находится в альфа-версии. Есть много ошибок

## OS

 * Windows
 * ~~Linux~~ (не поддерживается)
 * ~~Mac~~ (не поддерживается)

## Функции

 * Поддержка Minecraft 1.8, 1.9, 1.10, 1.11, 1.12, 1.13, 1.14, 1.15, 1.16, 1.17 и 1.18.
 * Анти афк
 * управление через чат
 * авто респавн
 * авто реконект
 * графический интерфейс

## Гайд

 * [YouTube](https://youtu.be/vpgzqO3YEDE)

## Установка

### Python

 * Python 3.9

```bash
pip install tkinter
pip install javascript
npm install mineflayer
pip install configparser
pip install threading
pip install webbrowser
```

### JS

 * Последний Node.js

```bash
npm install mineflayer
```

## Использование

### Python

 * Настройки в меню
 * py main.py

### JS

 * Нужно отредактировать это в файле:

```js
host: "localhost",
port: "25565",
username: "Test"
```
 * node main.js

### Управление через чат

 * ;pos - позиция бота в мире
 * ;start - включить анти афк
 * ;stop - выключить анти афк

## Спасибо

- [mineflayer](https://github.com/PrismarineJS/mineflayer)
